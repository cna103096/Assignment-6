﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace Assignment_6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Load_Chart(object sender, EventArgs e)
        {
            int[,] xyData = new int[5, 40];
            string[] inputData = new string[41];
            string[] seriesName = new string[5];

            try
            {
                //Read in data
                string inputLine;
                using (StreamReader inFile = new StreamReader("FanData.txt"))
                {
                    int index = 0;

                    inputLine = inFile.ReadLine();
                    while (inputLine != null)
                    {
                        inputData = inputLine.Split('-');

                        seriesName[index] = inputData[0];

                        for (int i = 1; i < inputData.Length; i++)
                        {
                            xyData[index, (i - 1)] = Convert.ToInt32(inputData[i]);
                        }

                        inputLine = inFile.ReadLine();
                        index++;
                    }
                }
            }
            catch (FileNotFoundException)
            {
                messageTextBox.Text = "Error! File not found.";
            }
            catch
            {
                messageTextBox.Text = "Unknown Error!";
            }

            try
            {
                //Populate data
                for (int i = 0; i < 5; i++)
                {
                    this.line_chart.Series[i].Name = seriesName[i];
                    for (int j = 0; j < 40; j += 2)
                    {
                        this.line_chart.Series[i].Points.AddXY(xyData[i, j], xyData[i, (j + 1)]);
                    }
                }
            }
            catch (ArgumentException)
            {
                messageTextBox.Text = "Error! Argument Exception.";
            }
            catch
            {
                messageTextBox.Text = "Unknown Error!";
            }
        }

        private void Button_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
