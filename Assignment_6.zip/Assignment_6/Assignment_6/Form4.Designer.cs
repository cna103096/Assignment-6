﻿namespace Assignment_6
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_Chart_Title = new System.Windows.Forms.Label();
            this.Button_Back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label_Chart_Title
            // 
            this.Label_Chart_Title.AutoSize = true;
            this.Label_Chart_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Chart_Title.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Chart_Title.Location = new System.Drawing.Point(13, 13);
            this.Label_Chart_Title.Name = "Label_Chart_Title";
            this.Label_Chart_Title.Size = new System.Drawing.Size(218, 42);
            this.Label_Chart_Title.TabIndex = 0;
            this.Label_Chart_Title.Text = "Chart Name";
            // 
            // Button_Back
            // 
            this.Button_Back.Location = new System.Drawing.Point(713, 415);
            this.Button_Back.Name = "Button_Back";
            this.Button_Back.Size = new System.Drawing.Size(75, 23);
            this.Button_Back.TabIndex = 1;
            this.Button_Back.Text = "Back";
            this.Button_Back.UseVisualStyleBackColor = true;
            this.Button_Back.Click += new System.EventHandler(this.Button_Back_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Button_Back);
            this.Controls.Add(this.Label_Chart_Title);
            this.Name = "Form2";
            this.Text = "Chart";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_Chart_Title;
        private System.Windows.Forms.Button Button_Back;
    }
}