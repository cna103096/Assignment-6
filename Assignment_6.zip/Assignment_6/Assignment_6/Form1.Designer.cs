﻿namespace Assignment_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Charts = new System.Windows.Forms.Label();
            this.Button_Chart_1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Button_Chart_2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Button_Chart_3 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.Button_Chart_4 = new System.Windows.Forms.Button();
            this.Button_Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Charts
            // 
            this.Charts.AutoSize = true;
            this.Charts.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Charts.ForeColor = System.Drawing.SystemColors.Control;
            this.Charts.Location = new System.Drawing.Point(17, 16);
            this.Charts.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Charts.Name = "Charts";
            this.Charts.Size = new System.Drawing.Size(206, 69);
            this.Charts.TabIndex = 0;
            this.Charts.Text = "Charts";
            // 
            // Button_Chart_1
            // 
            this.Button_Chart_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Chart_1.Location = new System.Drawing.Point(16, 129);
            this.Button_Chart_1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Chart_1.Name = "Button_Chart_1";
            this.Button_Chart_1.Size = new System.Drawing.Size(223, 44);
            this.Button_Chart_1.TabIndex = 1;
            this.Button_Chart_1.Text = "Chart 1";
            this.Button_Chart_1.UseVisualStyleBackColor = true;
            this.Button_Chart_1.Click += new System.EventHandler(this.Button_Chart_1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(247, 139);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(741, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "A line chart that estimates the number of fans of 5 popular franchises.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.Control;
            this.label3.Location = new System.Drawing.Point(247, 242);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(643, 29);
            this.label3.TabIndex = 6;
            this.label3.Text = "A column chart that displays the top ten rated steam games.";
            // 
            // Button_Chart_2
            // 
            this.Button_Chart_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Chart_2.Location = new System.Drawing.Point(16, 233);
            this.Button_Chart_2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Chart_2.Name = "Button_Chart_2";
            this.Button_Chart_2.Size = new System.Drawing.Size(223, 44);
            this.Button_Chart_2.TabIndex = 5;
            this.Button_Chart_2.Text = "Chart 2";
            this.Button_Chart_2.UseVisualStyleBackColor = true;
            this.Button_Chart_2.Click += new System.EventHandler(this.Button_Chart_2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Control;
            this.label5.Location = new System.Drawing.Point(247, 346);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(243, 29);
            this.label5.TabIndex = 10;
            this.label5.Text = "Description of Chart 3";
            // 
            // Button_Chart_3
            // 
            this.Button_Chart_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Chart_3.Location = new System.Drawing.Point(16, 336);
            this.Button_Chart_3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Chart_3.Name = "Button_Chart_3";
            this.Button_Chart_3.Size = new System.Drawing.Size(223, 44);
            this.Button_Chart_3.TabIndex = 9;
            this.Button_Chart_3.Text = "Chart 3";
            this.Button_Chart_3.UseVisualStyleBackColor = true;
            this.Button_Chart_3.Click += new System.EventHandler(this.Button_Chart_3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.Control;
            this.label4.Location = new System.Drawing.Point(247, 449);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(243, 29);
            this.label4.TabIndex = 14;
            this.label4.Text = "Description of Chart 4";
            // 
            // Button_Chart_4
            // 
            this.Button_Chart_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Chart_4.Location = new System.Drawing.Point(16, 439);
            this.Button_Chart_4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Chart_4.Name = "Button_Chart_4";
            this.Button_Chart_4.Size = new System.Drawing.Size(223, 44);
            this.Button_Chart_4.TabIndex = 13;
            this.Button_Chart_4.Text = "Chart 4";
            this.Button_Chart_4.UseVisualStyleBackColor = true;
            this.Button_Chart_4.Click += new System.EventHandler(this.Button_Chart_4_Click);
            // 
            // Button_Exit
            // 
            this.Button_Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Exit.Location = new System.Drawing.Point(971, 481);
            this.Button_Exit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Button_Exit.Name = "Button_Exit";
            this.Button_Exit.Size = new System.Drawing.Size(80, 42);
            this.Button_Exit.TabIndex = 15;
            this.Button_Exit.Text = "Exit";
            this.Button_Exit.UseVisualStyleBackColor = true;
            this.Button_Exit.Click += new System.EventHandler(this.Button_Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(1067, 538);
            this.Controls.Add(this.Button_Exit);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Button_Chart_4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.Button_Chart_3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Button_Chart_2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Button_Chart_1);
            this.Controls.Add(this.Charts);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Charts";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Charts;
        public System.Windows.Forms.Button Button_Chart_1;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Button_Chart_2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Button_Chart_3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Button_Chart_4;
        private System.Windows.Forms.Button Button_Exit;
    }
}

