﻿namespace Assignment_6
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.Label_Chart_Title = new System.Windows.Forms.Label();
            this.Button_Back = new System.Windows.Forms.Button();
            this.bar_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.messageTextBox = new System.Windows.Forms.TextBox();
            this.Button_Load = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bar_chart)).BeginInit();
            this.SuspendLayout();
            // 
            // Label_Chart_Title
            // 
            this.Label_Chart_Title.AutoSize = true;
            this.Label_Chart_Title.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Chart_Title.ForeColor = System.Drawing.SystemColors.Control;
            this.Label_Chart_Title.Location = new System.Drawing.Point(17, 16);
            this.Label_Chart_Title.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Label_Chart_Title.Name = "Label_Chart_Title";
            this.Label_Chart_Title.Size = new System.Drawing.Size(712, 54);
            this.Label_Chart_Title.TabIndex = 0;
            this.Label_Chart_Title.Text = "Top 10 Steam Games by Ratings";
            // 
            // Button_Back
            // 
            this.Button_Back.Location = new System.Drawing.Point(951, 511);
            this.Button_Back.Margin = new System.Windows.Forms.Padding(4);
            this.Button_Back.Name = "Button_Back";
            this.Button_Back.Size = new System.Drawing.Size(100, 28);
            this.Button_Back.TabIndex = 1;
            this.Button_Back.Text = "Back";
            this.Button_Back.UseVisualStyleBackColor = true;
            this.Button_Back.Click += new System.EventHandler(this.Button_Back_Click);
            // 
            // bar_chart
            // 
            chartArea1.AxisX.Interval = 1D;
            chartArea1.AxisX.Maximum = 11D;
            chartArea1.AxisX.Minimum = 0D;
            chartArea1.AxisX.Title = "Game";
            chartArea1.AxisY.Title = "Rating (%)";
            chartArea1.Name = "ChartArea1";
            this.bar_chart.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.bar_chart.Legends.Add(legend1);
            this.bar_chart.Location = new System.Drawing.Point(26, 83);
            this.bar_chart.Name = "bar_chart";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.bar_chart.Series.Add(series1);
            this.bar_chart.Size = new System.Drawing.Size(1025, 421);
            this.bar_chart.TabIndex = 2;
            this.bar_chart.Text = "chart1";
            // 
            // messageTextBox
            // 
            this.messageTextBox.Location = new System.Drawing.Point(26, 514);
            this.messageTextBox.Name = "messageTextBox";
            this.messageTextBox.ReadOnly = true;
            this.messageTextBox.Size = new System.Drawing.Size(810, 22);
            this.messageTextBox.TabIndex = 4;
            // 
            // Button_Load
            // 
            this.Button_Load.Location = new System.Drawing.Point(843, 511);
            this.Button_Load.Margin = new System.Windows.Forms.Padding(4);
            this.Button_Load.Name = "Button_Load";
            this.Button_Load.Size = new System.Drawing.Size(100, 28);
            this.Button_Load.TabIndex = 5;
            this.Button_Load.Text = "Load Chart";
            this.Button_Load.UseVisualStyleBackColor = true;
            this.Button_Load.Click += new System.EventHandler(this.Load_Chart);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlText;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.Button_Load);
            this.Controls.Add(this.messageTextBox);
            this.Controls.Add(this.bar_chart);
            this.Controls.Add(this.Button_Back);
            this.Controls.Add(this.Label_Chart_Title);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form3";
            this.Text = "Chart";
            ((System.ComponentModel.ISupportInitialize)(this.bar_chart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Label_Chart_Title;
        private System.Windows.Forms.Button Button_Back;
        private System.Windows.Forms.DataVisualization.Charting.Chart bar_chart;
        private System.Windows.Forms.TextBox messageTextBox;
        private System.Windows.Forms.Button Button_Load;
    }
}