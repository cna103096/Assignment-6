﻿/* Z1829678 - Christopher Adams
 * Z1805732 - Kevin Lewis 
 *                                      
 * 
 * CSCI 473 - Assignment 6: Charts
 * 4 unique charts that are opened in new windows, only one window open at a time
 * */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using System.Windows.Forms;

namespace Assignment_6
{
    

    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Button_Chart_1_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            var formTwo = new Form2();
            //when form2 is closed, open form 1 again
            formTwo.Closed += (s, args) => this.Show();
            formTwo.Show();
        }

        private void Button_Chart_2_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formThree = new Form3();
            //when form3 is closed, open form 1 again
            formThree.Closed += (s, args) => this.Show();
            formThree.Show();
        }

        private void Button_Chart_3_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formFour = new Form4();
            //when form4 is closed, open form 1 again
            formFour.Closed += (s, args) => this.Show();
            formFour.Show();
        }

        private void Button_Chart_4_Click(object sender, EventArgs e)
        {
            this.Hide();
            var formFive = new Form5();
            //when form5 is closed, open form 1 again
            formFive.Closed += (s, args) => this.Show();
            formFive.Show();
        }

        private void Button_Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
