﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Assignment_6
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Load_Chart(object sender, EventArgs e)
        {
            string[] xData = new string[10];
            double[] yData = new double[10];
            string[] inputData = new string[21];
            string seriesName = " ";

            try
            {
                //Read in data
                string inputLine;
                using (StreamReader inFile = new StreamReader("SteamData.txt"))
                {
                    inputLine = inFile.ReadLine();
                    while (inputLine != null)
                    {
                        inputData = inputLine.Split('-');

                        seriesName = inputData[0];

                        for (int i = 1; i < 11; i++)
                        {
                            xData[(i - 1)] = inputData[i];
                        }

                        for (int i = 11; i < 21; i++)
                        {
                            yData[(i - 11)] = Convert.ToDouble(inputData[i]);
                        }

                        inputLine = inFile.ReadLine();
                    }
                }
            }
            catch (FileNotFoundException)
            {
                messageTextBox.Text = "Error! File not found.";
            }
            catch
            {
                messageTextBox.Text = "Unknown Error!";
            }

            //Populate data
            this.bar_chart.Series[0].Name = seriesName;
            for (int i = 0; i < 10; i++)
            {
                this.bar_chart.Series[0].Points.AddXY(xData[i], yData[i]);
            }
        }

        private void Button_Back_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
